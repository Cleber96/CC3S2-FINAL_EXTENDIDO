package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Clima {
/*
    private List<Sensor> sensores;
    private List<Boolean> banderas;

    private static Scanner in;

    public Clima() {
        sensores = new ArrayList<>();
        banderas = new ArrayList<>();
        Temperatura temperatura_ = new Temperatura(0);
        sensores.add(temperatura_);
        LLuvia cantLLuvia_ = new LLuvia(0);
        sensores.add(cantLLuvia_);
        Viento velocidadViento_ = new Viento(0);
        sensores.add(velocidadViento_);
        Humedad humedad_ = new Humedad(0);
        sensores.add(humedad_);
        PresionAtmosferica presionAtm_ = new PresionAtmosferica(0);
        sensores.add(presionAtm_);
    }

    public void alertas() {
        for (Sensor sensor : sensores) {
            banderas.add(sensor.verificarAlerta());
        }
    }

    public List<String> accionesAutomaticas() {
        List<String> auto = new ArrayList<>();
        System.out.println("__ ACCIONES AUTOMÁTICAS __");
        for (int i = 0; i < banderas.size(); i++) {
            if(banderas.get(i)) {
                auto.add(sensores.get(i).getAuxiliar());
            } else {
                auto.add("");
            }
        }
        return auto;
    }

    public List<String> notificaciones() {
        List<String> auto = new ArrayList<>();
        System.out.println("__ NOTIFICACIONES __");
        for (int i = 0; i < banderas.size(); i++) {
            if(banderas.get(i)) {
                auto.add(sensores.get(i).getMensajeAlerta());
            } else {
                auto.add("");
            }
        }
        return auto;
    }
    public void imprimir(List<String> resultados) {
        for(String resultado: resultados) {
            if(resultado.equalsIgnoreCase("")) {
                System.out.println(resultado);
            }
        }
    }
    public void menu() {
        System.out.println("***** MENÚ *****:");
        System.out.println("__ ELIJA UNA OPCIÓN __");
        System.out.println("1. Temperatura en Celsius: ");
        System.out.println("2. Cantidad de LLuvia en mm.: ");
        System.out.println("3. Velocidad del Viento en km/h: ");
        System.out.println("4. Humedad en porcentaje: ");
        System.out.println("5. Presion Atmosferica en hPa: ");
        System.out.print("OPCION ELEGIDA: ");
        int opcion = in.nextInt();
        opcionElegida(opcion);
    }
    public void opcionElegida(int opcion) {
        if(opcion<6 && opcion>0) {
            System.out.print("MEDIDA REGISTRADA: ");
            int medida = in.nextInt();
            sensores.get(opcion-1).setValor(medida);
        }
    }
    public static void main(String[] args) {
        in = new Scanner(System.in);
        Clima clima = new Clima();
        clima.menu();
        clima.alertas();
        System.out.println("***** RESULTADOS *****");
        clima.imprimir(clima.accionesAutomaticas());
        clima.imprimir(clima.notificaciones());
        in.close();
    }
    */

}

