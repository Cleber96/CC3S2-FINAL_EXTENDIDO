package org.example;

public interface Alerta {
    boolean verificar(double valor, double umbral);
}
